# customer-sentiment-analyzer
AI-powered .NET Core web app to analyze customer sentiment for beverage brands using reviews or social media data.
